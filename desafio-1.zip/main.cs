using System;
class Program{
    static void Main() {

        Console.WriteLine("Digite ");
        int A = int.Parse(Console.ReadLine());
        int B = int.Parse(Console.ReadLine());
        int C = int.Parse(Console.ReadLine());
        int media = (A+B+C)/3;

        System.Console.WriteLine("A média é: " + media);




    }
}